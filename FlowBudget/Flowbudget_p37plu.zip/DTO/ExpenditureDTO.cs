using DTO;

namespace FlowBudget.Client.Components.DTO;

public class ExpenditureDTO
{
    public string Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public DateTime Date { get; set; }
    public string? Description { get; set; }
    public string Currency { get; set; }
    public CategoryDTO? Category { get; set; }
    public string PocketName { get; set; } = string.Empty;
    public string AccountId { get; set; } = string.Empty;
    public string? WishlistId { get; set; }
    public string? WishlistName { get; set; }
}

public class ExpenditureStatsDTO
{
    public decimal Monthly { get; set; }
    public decimal Weekly { get; set; }
}

public class CreateExpenditureDTO
{
    public string Name { get; set; }
    public decimal Price { get; set; }
    public string? Description { get; set; }
    public string? CategoryId { get; set; }
    public string? PocketId { get; set; }
    
    public DateTime? Date { get; set; }
}

public class UpdateExpenditureDTO
{
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string? Description { get; set; }
}

public class ExpenditureReceiptItemDTO
{
    public string Name { get; set; }
    public decimal Price { get; set; }
    // The AI returns the field as category
    [System.Text.Json.Serialization.JsonPropertyName("category")]
    public string? CategoryId { get; set; }
}

public class ReceiptRow
{
    public bool Include { get; set; } = true;
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string? CategoryId { get; set; }
}